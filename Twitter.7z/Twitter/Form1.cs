namespace Twitter
{
    public partial class Twitter : Form
    {
        public Twitter()
        {
            InitializeComponent();
        }

        private void PostButton_Click(object sender, EventArgs e)
        {
            string input, output;
            input = inputBox.Text;
            if (input.Length > 140)
                output = "Error - Message too long.";
            else
                output = input;
            display.Text = output;

        }
    }
}
