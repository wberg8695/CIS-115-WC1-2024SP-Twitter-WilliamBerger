﻿namespace Twitter
{
    partial class Twitter
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            display = new Label();
            inputBox = new TextBox();
            postButton = new Button();
            SuspendLayout();
            // 
            // display
            // 
            display.BackColor = SystemColors.ControlLight;
            display.BorderStyle = BorderStyle.Fixed3D;
            display.Location = new Point(50, 122);
            display.Name = "display";
            display.Size = new Size(500, 25);
            display.TabIndex = 0;
            // 
            // inputBox
            // 
            inputBox.Location = new Point(50, 39);
            inputBox.Name = "inputBox";
            inputBox.Size = new Size(500, 27);
            inputBox.TabIndex = 1;
            // 
            // postButton
            // 
            postButton.Location = new Point(240, 81);
            postButton.Name = "postButton";
            postButton.Size = new Size(94, 29);
            postButton.TabIndex = 2;
            postButton.Text = "Post";
            postButton.UseVisualStyleBackColor = true;
            postButton.Click += PostButton_Click;
            // 
            // Twitter
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(612, 193);
            Controls.Add(postButton);
            Controls.Add(inputBox);
            Controls.Add(display);
            Name = "Twitter";
            Text = "Twitter";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label display;
        private TextBox inputBox;
        private Button postButton;
    }
}
